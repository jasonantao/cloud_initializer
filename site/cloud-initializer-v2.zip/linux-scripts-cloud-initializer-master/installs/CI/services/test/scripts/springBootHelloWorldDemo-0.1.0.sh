java -jar /etc/init.d/services/test/java/libs/springBootHelloWorldDemo-0.1.0.jar
