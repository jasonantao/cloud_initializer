pkg=CI
scriptType="apps"
echo "reinstall.sh EXECUTING: . ./reinstall.sh $scriptType $pkg"
. ./reinstall.sh $scriptType $pkg
