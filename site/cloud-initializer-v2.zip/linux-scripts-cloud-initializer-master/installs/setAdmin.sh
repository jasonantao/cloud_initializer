#SET UP REINSTALL
echo Setup.sh:  EXECUTING: cp $installDir/reinstall.sh $parentDir/$pkg-RECOVERY.sh
cp $installDir/reinstall.sh $parentDir/$pkg-RECOVERY.sh
