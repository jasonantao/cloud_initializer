yum remove mysql mysql-server
