grant usage on *.* to admin@localhost identified by 'password';
grant all privileges on mywpwebsite.* to admin@localhost;

use mywpwebsite;
