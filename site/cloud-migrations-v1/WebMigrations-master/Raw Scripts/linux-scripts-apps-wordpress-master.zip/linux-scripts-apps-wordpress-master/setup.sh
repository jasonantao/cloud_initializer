#Setup File PLACEHOLDER
. ./env/setEnv.sh
echo "WordPress has now succesfully been installed and a database created."
mysql USE mywpwebsite;
echo "WordPress has now succesfully been installed and a database created."
