#! /bin/bash
# Setup the required environment
. ./env/setEnv.sh#
./installGenDevTools.sh
./installRepositories.sh
./installNodeJS.sh
./installJava8.sh
