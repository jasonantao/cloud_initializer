# OPTIONAL REPOSITORIES
yum install git -y
yum install svn
