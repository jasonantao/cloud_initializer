# WILDFLY CONFIGURATION PARAMETERS
pkg=wildfly
wfAdmin=admin
wfOwner=wildfly
wfGroup=wildfly
wfHome=/opt/wildfly
wfLog=/var/log/wildfly
