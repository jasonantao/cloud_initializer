# <b>Package XXXXXX CopyRight** ©</b> <img src="https://github.com/RMelanson/linux-scripts-bootstraps/blob/master/images/policeman.png" width="5%" align= "right">

- This program is free for re-distribution provided this copyright/license header is left in place.  
- There is no warranty or guaranty of any kind in any way and is not assured to be as required and may not work exactly as designed for all os systems operating various potentially conflicting software.  
- It is recommended to read the contents of the scripts to be assured of the installation process and what will be installed. 
- The user is free to modify the code as required. 
- There may not be an associated uninstal script, so uninstalling is the owners responsibility.
- It is recommended to be installed on a test system in a test environment before promoting to a production environment.
#
## <b>**Install at your own Risk</b>
