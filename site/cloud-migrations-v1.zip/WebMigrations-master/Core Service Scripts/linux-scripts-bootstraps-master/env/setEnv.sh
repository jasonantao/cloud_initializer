set -o vi
export BASE_INSTALL=/tmp/scripts
export SW_HOME=/home/SW_HOME
